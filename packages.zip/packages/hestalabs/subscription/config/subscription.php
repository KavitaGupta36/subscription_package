<?php

return [

    'subscription_model' 		=> Hestalabs\Subscription\Models\SubscriptionPlan::class,
    'user_subscription_model' 	=> Hestalabs\Subscription\Models\UserSubscription::class,

    /**
     * Define custom database table names - without prefixes.
     */
    //'messages_table' => null,
];