# The license

Copyright (c) Shahrukh anwar <friends@gmail.com>

...Add your license text here...